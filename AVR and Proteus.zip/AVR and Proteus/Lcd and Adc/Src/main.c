#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#include "lcd.h"
#include "adc.h"

int main(void){
   adcInit();
   lcdInit();
   DDRC = 0x00;
   char adcStr[10];
   float celsius, temperature;
   lcdString("LaurinCorp Inc.");
   while(1){
      lcdCmd(0xC0);
      uint16_t adc = adcRead(0);
      celsius = (adc*4.88);
      temperature = (celsius/10.00);
      sprintf(adcStr, "Temp : %d%cC", (int)temperature, 0xdf);
      lcdString(adcStr);
      _delay_ms(80);
   }
   return 0;
}