int cmp(char str[], char str2[]){
   unsigned int i = 0;
   while(str[i] != '\0'){
      if(str[i] != str2[i]){
	 return 0;
      }
      i++;
   }
   return 1;
}