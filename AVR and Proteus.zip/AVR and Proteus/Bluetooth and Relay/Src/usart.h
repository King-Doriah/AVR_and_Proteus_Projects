void initUSART(void){
   UBRR0 = 103;//USART BAUD RATE REGISTER 0 | 103 = 9600
   UCSR0B |= (1<<RXEN0)|(1<<TXEN0);
   UCSR0C |= (1<<UCSZ01)|(1<<UCSZ00);
}

char usart_receive(void){
   while(!(UCSR0A & (1<<RXC0)));
   return UDR0;
}

void usart_transmit(char data){
   while(!(UCSR0A & (1<<UDRE0)));
   UDR0 = data;
}

void usart_print(char data[]){
   unsigned int i = 0;
   while(data[i] != '\0'){
      usart_transmit(data[i]);
      i++;
   }
}

void usart_println(char data[]){
   usart_print(data);
   usart_transmit(0x0A);
   usart_transmit(0x0D);
}

void usart_string(char data[]){
   char ch;
   unsigned int i = 0;
   while(1){
      ch = usart_receive();
      if(ch == '\n' || ch == '\0' || ch == '\r'){
	 data[i] = '\0';
	 i = 0;
	 break;
      }else{
	data[i] = ch;
	i++; 
      }
   }
}