#include <avr/io.h>
#include "usart.h"
#include "func.h"

int main(void){
   DDRB = 0x20;
   char data[50];

   
   initUSART();
   
   while(1){
      usart_string(data);
      usart_println(data);
      if(cmp(data, "ligar")){
	 PORTB = 0x20;
      }else if(cmp(data, "desligar")){
	 PORTB = ~0x20;
      }
   }
   return 0;
}

      /*
      char data = usart_receive();
      usart_transmit(data);
      if(data == 'l' || data == 'L'){
	 PORTB |= (1<<PB5);
      }else if(data == 'd' || data == 'D'){
	 PORTB &= ~(1<<PB5);
      }*/