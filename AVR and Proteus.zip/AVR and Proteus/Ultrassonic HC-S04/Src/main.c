#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#include "lcd.h"
#include "macros.h"

#define dir_pin	DDRB
#define ut_port	PORTB
#define ts_port	PINB
#define trigger PB5
#define echo	PB6

void initUltrassonic(void){
   set_bit(dir_pin,trigger);
   clr_bit(dir_pin,echo);
   TCCR1B |= (1<<CS10);
}

uint16_t distanceHCS04(void){
   //distance = duration/58.8;
   
   uint16_t distance;
   
   set_bit(ut_port,trigger);
   _delay_us(10);
   clr_bit(ut_port,trigger);
   
   while(!tst_bit(ts_port,echo));
   
   TCNT1 = 1;
   while(tst_bit(ts_port,echo));
   
   distance = TCNT1/58.8;
   TCNT1 = 0;
   
   return distance;
}

int main(void){
   initUltrassonic();
   lcdInit();
   char dist[10];
   while(1){
      lcdString("LaurinCorp Inc.");
      lcdCmd(0xC0);
      uint16_t distance = distanceHCS04();
      sprintf(dist, "Dist : %d", distance);
      lcdString(dist);
      _delay_ms(100);
      lcdClear();
   }
   return 0;
}