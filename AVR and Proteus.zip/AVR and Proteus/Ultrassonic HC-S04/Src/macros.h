#define set_bit(P,bit)	(P|=(1<<bit))
#define clr_bit(P,bit)	(P&=~(1<<bit))
#define tst_bit(P,bit)	(P&(1<<bit))