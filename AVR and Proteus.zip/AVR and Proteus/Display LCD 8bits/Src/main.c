#include <avr/io.h>
#include <util/delay.h>
#include "lcd8bits.h"

int main(void){
    lcdInit();
    char str[]="Miraldino Paulo";
    lcdString(str);
    while(1);
}