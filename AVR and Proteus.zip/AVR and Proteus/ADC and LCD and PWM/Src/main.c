#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#include "adc.h"
#include "lcd.h"

int main(void){
   DDRD = 0xFF;
   DDRC = 0x00;
   lcdInit();
   Init_ADC();
   TCCR0A = (1<<WGM00)|(1<<COM0A1);
   TCCR0B = (1<<CS02);
   char adcStr[50];
   while(1){
      uint16_t adc = Read_ADC(0);
      sprintf(adcStr, "  ADC = %d%%", (adc/4));
      OCR0A = (adc/4);
      lcdString(adcStr);
      _delay_ms(80);
      lcdClear();
   }
   return 0;
}