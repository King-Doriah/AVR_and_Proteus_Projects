void Init_ADC(void){
    ADMUX = (1<<REFS0);
    ADCSRA = (1<<ADEN) | (1<<ADPS2) | (1<<ADPS1);
}

uint16_t Read_ADC(int channel){
   ADMUX = (ADMUX & 0x0F8) | (channel & 0x07);
   ADCSRA |= (1<<ADSC);
   while(ADCSRA & (1<<ADSC));
   return ADC;
}