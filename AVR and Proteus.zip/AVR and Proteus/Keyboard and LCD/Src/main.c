#include <avr/io.h>
#include <util/delay.h>
#include "lcd.h"
#include "keyboard.h"

int main(void){

   lcdInit();
   KeyboardInit();
   while(1){
      char key = Keyboard();
      _delay_ms(20);
      if(key != 'n'){
	 lcdData(key);
      }
   }
   return 0;
}

