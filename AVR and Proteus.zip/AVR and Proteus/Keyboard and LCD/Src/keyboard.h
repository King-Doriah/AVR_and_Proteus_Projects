#define Keyboard_DDR	DDRD
#define Keyboard_PORT	PORTD
#define	Keyboard_ST	PIND
#define	COL1		PD0
#define	COL2		PD1
#define	COL3		PD2
#define ROW_A		PD3
#define ROW_B		PD4
#define ROW_C		PD5
#define ROW_D		PD6

void KeyboardInit(void){
   Keyboard_DDR = 0x07;
   Keyboard_PORT = 0x78;
}

char Keyboard(void){
   Keyboard_PORT |= 0x06;
   Keyboard_PORT &= ~(1<<COL1);
   if(!(Keyboard_ST & (1<<ROW_A))){ _delay_ms(30); while(!(Keyboard_ST & (1<<ROW_A))); return '1'; };
   if(!(Keyboard_ST & (1<<ROW_B))){ _delay_ms(30); while(!(Keyboard_ST & (1<<ROW_B))); return '4'; };
   if(!(Keyboard_ST & (1<<ROW_C))){ _delay_ms(30); while(!(Keyboard_ST & (1<<ROW_C))); return '7'; };
   if(!(Keyboard_ST & (1<<ROW_D))){ _delay_ms(30); while(!(Keyboard_ST & (1<<ROW_D))); return '*'; };

   Keyboard_PORT |= 0x05;
   Keyboard_PORT &= ~(1<<COL2);
   if(!(Keyboard_ST & (1<<ROW_A))){ _delay_ms(30); while(!(Keyboard_ST & (1<<ROW_A))); return '2'; };
   if(!(Keyboard_ST & (1<<ROW_B))){ _delay_ms(30); while(!(Keyboard_ST & (1<<ROW_B))); return '5'; };
   if(!(Keyboard_ST & (1<<ROW_C))){ _delay_ms(30); while(!(Keyboard_ST & (1<<ROW_C))); return '8'; };
   if(!(Keyboard_ST & (1<<ROW_D))){ _delay_ms(30); while(!(Keyboard_ST & (1<<ROW_D))); return '0'; };

   Keyboard_PORT |= 0x03;
   Keyboard_PORT &= ~(1<<COL3);   
   if(!(Keyboard_ST & (1<<ROW_A))){ _delay_ms(30); while(!(Keyboard_ST & (1<<ROW_A))); return '3'; };
   if(!(Keyboard_ST & (1<<ROW_B))){ _delay_ms(30); while(!(Keyboard_ST & (1<<ROW_B))); return '6'; };
   if(!(Keyboard_ST & (1<<ROW_C))){ _delay_ms(30); while(!(Keyboard_ST & (1<<ROW_C))); return '9'; };
   if(!(Keyboard_ST & (1<<ROW_D))){ _delay_ms(30); while(!(Keyboard_ST & (1<<ROW_D))); return '#'; };
   
   return 'n';
}
