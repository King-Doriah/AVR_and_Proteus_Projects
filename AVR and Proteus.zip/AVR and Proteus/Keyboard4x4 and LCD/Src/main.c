#include <avr/io.h>
#include <util/delay.h>
#include "lcd8bits.h"
#include "keyboard4x4.h"

char calcKey(void);

int main(void){
   
   keyboard4x4Init();
   lcdInit();
   lcdString("Miraldino");
   lcdCmd(0xC0);
   while(1){
      char ch = keyboard4x4Read();
      _delay_ms(20);
      if(ch != 'n'){
	 lcdData(ch);
      }
   }
}

