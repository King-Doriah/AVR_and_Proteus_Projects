#define LCD_DDR  DDRD
#define LCD_CMD    DDRC
#define LCD_PORT PORTD
#define LCD_CMDP PORTC
#define RS   PC2
#define EN   PC3

void lcdCmd(char cmd){
   LCD_PORT = cmd;
   LCD_CMDP &= ~(1<<RS);
   LCD_CMDP |= (1<<EN);
   _delay_ms(2);
   LCD_CMDP &= ~(1<<EN);
   _delay_ms(2);
}

void lcdData(char data){
   LCD_PORT = data;
   LCD_CMDP |= (1<<RS);
   LCD_CMDP |= (1<<EN);
   _delay_ms(2);
   LCD_CMDP &= ~(1<<EN);
   _delay_ms(2);
}

void lcdString(char str[]){
   unsigned int i = 0;
   while(str[i] != '\0'){
      lcdData(str[i]);
      i++;
   }
}

void lcdClear(void){
   lcdCmd(0x01);
   lcdCmd(0x80);
}

void lcdInit(void){
   //Init DDR's
   LCD_DDR = 0xFF;
   LCD_CMD |= (1<<RS) | (1<<EN);

   lcdCmd(0x38);
   lcdCmd(0x06);
   lcdCmd(0x0C); //0x0F => Habilita o Cursor
   lcdCmd(0x03);
   lcdCmd(0x01);
   lcdCmd(0x80);    
}
