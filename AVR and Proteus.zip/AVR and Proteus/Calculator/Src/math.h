int calcular(int num, int num2, char op){
   int result = 0;
   switch(op){
      case '+':
	 result = num + num2;
	 break;
      case '-':
	 result = num - num2;
	 break;
      case 'x':
	 result = num * num2;
	 break;
      case '/':
	 result = num / num2;
	 break;
   }
   return result;
}