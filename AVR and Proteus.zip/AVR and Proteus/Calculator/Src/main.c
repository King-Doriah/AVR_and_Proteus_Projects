#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lcd8bits.h"
#include "keyboard4x4.h"
#include "math.h"

char calcKey(void);

int main(void){
   char key[50]={0};
   int i = 0, result = 0;
   keyboard4x4Init();
   lcdInit();

   char disp[60]={0};
   while(1){
      char ch = keyboard4x4Read();
      _delay_ms(20);
      if(ch != 'n'){
	 if(ch == '+' || ch == '-' || ch == 'x' || ch == '/'){
	    lcdClear();
	    key[i] = ch;
	    i = 0;
	    char op = ch;
	    int num = atoi(key);
	    memset(key, 0, sizeof(key));
	    sprintf(disp, "%d%c", num, op);
	    lcdString(disp);
	    while(1){
	       ch = keyboard4x4Read();
	       _delay_ms(20);
	       if(ch != 'n'){
		  if(ch == '='){
		     lcdClear();
		     key[i] = ch;
		     i = 0;
		     int num2 = atoi(key);
		     memset(key, 0, sizeof(key));
		     result = calcular(num, num2, op);
		     sprintf(disp, "%d%c%d=%d", num, op, num2, result);
		     lcdString(disp);
		     lcdCmd(0xC0);
		     lcdString("Clear Screen!!!");
		     break;
		  }else if(ch == 'c'){
		     lcdClear();
		     memset(key, 0, sizeof(key));
		     i = 0;
		     break;
		  }else if(ch == '+' || ch == '-' || ch == 'x' || ch == '/'){
		     lcdCmd(0xC0);
		     lcdString("Fail Operation!");
		     _delay_ms(1000);
		     lcdClear();
		     memset(key, 0, sizeof(key));
		     i = 0;
		     break;
		  }else{
		     key[i] = ch;
		     lcdData(key[i]);
		     i++;
		  }
	       }
	    }
	 }else if(ch == '='){
	    lcdString("Fail Operation!");
	    _delay_ms(1000);
	    lcdClear();
	    memset(key, 0, sizeof(key));
	    i = 0;
	 }else if(ch == 'c'){
	    lcdClear();
	    memset(key, 0, sizeof(key));
	    i = 0;
	 }else{
	    key[i] = ch;
	    lcdData(key[i]);
	    i++;
	 }
      }
   }
}

